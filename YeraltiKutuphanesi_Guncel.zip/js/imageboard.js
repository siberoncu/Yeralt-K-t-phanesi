
document.getElementById("postForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const imageInput = document.getElementById("image");
    const textInput = document.getElementById("text");

    if (!imageInput.files[0]) return;

    const reader = new FileReader();
    reader.onload = function() {
        const postDiv = document.createElement("div");
        postDiv.className = "post";

        const img = document.createElement("img");
        img.src = reader.result;

        const para = document.createElement("p");
        para.textContent = textInput.value;

        postDiv.appendChild(img);
        postDiv.appendChild(para);

        document.getElementById("gallery").prepend(postDiv);
    };

    reader.readAsDataURL(imageInput.files[0]);

    imageInput.value = "";
    textInput.value = "";
});
